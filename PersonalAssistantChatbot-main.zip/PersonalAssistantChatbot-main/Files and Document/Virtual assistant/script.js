function showText() {
	document.getElementById("label").innerHTML="Successfully Created Virtual assistant Project";
	document.getElementById("btn").style="background-color:green;"
}