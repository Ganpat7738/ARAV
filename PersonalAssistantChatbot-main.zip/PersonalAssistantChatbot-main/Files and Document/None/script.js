function showText() {
	document.getElementById("label").innerHTML="Successfully Created None Project";
	document.getElementById("btn").style="background-color:green;"
}