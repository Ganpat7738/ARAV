function showText() {
	document.getElementById("label").innerHTML="Successfully Created A n Project";
	document.getElementById("btn").style="background-color:green;"
}